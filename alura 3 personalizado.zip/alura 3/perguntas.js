criaCartao(
    'Dragon Ball Z',
    'Qual o nome do príncipe saiyajin?',
    'Vegeta'
)

criaCartao(
    'Jujutsu Kaisen',
    'Quem é conhecido como o Rei Das Maldições?',
    'Ryomen Sukuna'
)

criaCartao(
    'Kimetsu no Yaiba',
    'Quem é o lua superior 1?',
    'Kokushibou'
)

criaCartao(
    'Naruto',
    ' Quem criou a Akatsuki? ',
    'Yahiko'
)